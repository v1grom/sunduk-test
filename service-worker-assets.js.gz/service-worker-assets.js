self.assetsManifest = {
  "version": "uvVdOUgd",
  "assets": [
    {
      "hash": "sha256-53l0jf516E+XTfPHvAf4QgEaEAFZFYsPH0my8qWlFcs=",
      "url": "LICENSE.txt"
    },
    {
      "hash": "sha256-Pk2JaQ8+TlUcAQ9zc92iyeR2qyGUbZhFjmBRFVkjhTM=",
      "url": "Sunduk.styles.css"
    },
    {
      "hash": "sha256-DPDTyAlkcs8nhi9Nli6ZcH0rBDW3BvazF7S1LWlbdOs=",
      "url": "_content/Blazor.Common/Blazor.Common.bundle.scp.css"
    },
    {
      "hash": "sha256-9HqSi7f3WPkQgSjx/x2OW8SW2zCvKHc7RLV+OrD9Rw8=",
      "url": "_content/Blazor.Common/blazorCommon.css"
    },
    {
      "hash": "sha256-1DCaWZyeaJsmlJbPqXkRyVrYk8z0mjKnlfxxMo5LzKQ=",
      "url": "_content/Blazor.Common/blazorCommon.js"
    },
    {
      "hash": "sha256-WeOKCkI7IdJHs2kCqsKgLfiWX4/sNPbaRUspOLefkCY=",
      "url": "_content/Blazor.Text.Editor/background.png"
    },
    {
      "hash": "sha256-Et7s6UoBg6T/pdpEHO9dG5QlpiEm71ONxK/NPmLspVk=",
      "url": "_content/Blazor.Text.Editor/blazorTextEditor.css"
    },
    {
      "hash": "sha256-WVbjdcjjg85rTUOCpgQa02aJgNxG9kWnSNaMhH710ak=",
      "url": "_content/Blazor.Text.Editor/blazorTextEditor.js"
    },
    {
      "hash": "sha256-PtApvXsjtN3h6TrGmJjCQsaFMN/pyLARBUCEQhLn7Oc=",
      "url": "_content/BlazorDownloadFile/BlazorDownloadFileScript.js"
    },
    {
      "hash": "sha256-7x17lQmvyREaNJcuhhzOnPBxhQNll71LT/G7IZHgjZ4=",
      "url": "_content/CodeBeam.MudBlazor.Extensions/MudExtensions.min.css"
    },
    {
      "hash": "sha256-DOAWyIfCMTFbctHQvyujh+XO9tJbLtdsXw9h0oQm3bM=",
      "url": "_content/CodeBeam.MudBlazor.Extensions/MudExtensions.min.js"
    },
    {
      "hash": "sha256-G3hYUw4Ps9P/IQ3lw2zu96RSZaOf4zU+4QkXkH8Xi3Y=",
      "url": "_content/CodeBeam.MudBlazor.Extensions/Mud_Secondary.png"
    },
    {
      "hash": "sha256-1GL+TjmZdDm3eGG+MG1FLkkZF8SOwo3eG/7qsNX0HuU=",
      "url": "_content/CodeBeam.MudBlazor.Extensions/eraser.cur"
    },
    {
      "hash": "sha256-oDnErTJbRIXAeq4Awzx/PNkRW2XA0ClXG7BIA/jTt9E=",
      "url": "_content/CodeBeam.MudBlazor.Extensions/pencil.cur"
    },
    {
      "hash": "sha256-NdeQbcZzX5UCyhBUMBYSSyLHnyuMzKW5phoTOZoa4YE=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-2Fm1DUwISFFaJIJ4Hrw5KGksHbLa7XH/f1SMMJzqEMI=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-+PCmxKmLji7XMKNDzPz53IGOL801McznPXXLuuvPA2I=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-Z0b2rs5SRtj5hF4glAphPoAQ6sKppyzSQK+OFLV9dug=",
      "url": "_framework/BlazorCommon.RazorLib.16kegff3l9.wasm"
    },
    {
      "hash": "sha256-YB8HlaKSU6hGhkiMwSSlwRa4MDljnOAAmxBFTAqQWes=",
      "url": "_framework/BlazorDownloadFile.ct05c4bfyq.wasm"
    },
    {
      "hash": "sha256-/R519wQm/580GkrgrvCj5FIKe48oEcQHHo38uM1aktw=",
      "url": "_framework/BlazorTextEditor.RazorLib.xjbeptu7ek.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D34x31UkRErVMwTY7JyB/1W1dwLAgjS1Xs66UUNSLe8=",
      "url": "_framework/CodeBeam.MudBlazor.Extensions.xk869mpbs2.wasm"
    },
    {
      "hash": "sha256-lWDwDWyFrbjUNOd82Ctxkz3R9/sAHg58V6AvObRnpjw=",
      "url": "_framework/ExtendedNumerics.BigDecimal.v3ins63tve.wasm"
    },
    {
      "hash": "sha256-l9mpfc3uKE7qBwg9jiFMD4R1q2ny0aAK4+x59q0cQW8=",
      "url": "_framework/Fluxor.Blazor.Web.t7pbu5cck5.wasm"
    },
    {
      "hash": "sha256-IH5E9XoP53JhRfLwU50gWDfm0kUscJNYvO9hzRIGnio=",
      "url": "_framework/Fluxor.c1zj64zb2d.wasm"
    },
    {
      "hash": "sha256-nzoyZeZ+gX8AWJ80fK5CRyqc6CJFmI/2j/9FZp3qWNY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.nuxtubsley.wasm"
    },
    {
      "hash": "sha256-2Q2qKAXsyTI+M1KnwdCwIDZ0NxT5UVuiTTPNQrdguDg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.1m4agmfrs4.wasm"
    },
    {
      "hash": "sha256-Tmrdwt5CUghDz2VJJdNkvWlCOU0ngmpWlY46212Y250=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.iv6y7zwty3.wasm"
    },
    {
      "hash": "sha256-IUy5t9z7cnwlfkaEg9S0DtL2sUQVi1mXXhY5VrDE+BA=",
      "url": "_framework/Microsoft.AspNetCore.Components.t16y5p9xp4.wasm"
    },
    {
      "hash": "sha256-LRrW/S2jAmMqf71EuwOxgMbVdrDu7QppjlK8PjiYgAU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.phvn7pjmsp.wasm"
    },
    {
      "hash": "sha256-5bJobl2CmVmcJLLFnz9CCdj3xIaEyZ6a0VAD0d5/IkQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jygd6wn873.wasm"
    },
    {
      "hash": "sha256-1aGbfOlRd6kBdGEEqlYjVobtmuQdh5hT1QGpwzeuYD4=",
      "url": "_framework/Microsoft.Extensions.Configuration.t6ukke4ckb.wasm"
    },
    {
      "hash": "sha256-U0klmRwnAmlTBUd3xKwMvbbAXesbHTUvA4wE/cqAt2s=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.f5tbt5v6ow.wasm"
    },
    {
      "hash": "sha256-7rMerIWAgrBbLaybLGGqyezXD1ZjEAfIzufHCE3IXiY=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.e0q98w4oo7.wasm"
    },
    {
      "hash": "sha256-DqfPKAYHP77xraGgNE6Ir3uX7roDIElJhyu+VYZSBN4=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.q6gottep8d.wasm"
    },
    {
      "hash": "sha256-t1lHoCEJ7O29td+SQmt0Ivo/BKkypLounZe6pGFJQFk=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.9oyj04e0d0.wasm"
    },
    {
      "hash": "sha256-ZbTnZVFsW5YBhb5oMBSOB+sbuloQvsjuUYZ8boT2RuA=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.xt73qsqilp.wasm"
    },
    {
      "hash": "sha256-L2P/tLhZ6FSR1KG27vIE/jer8JBjOAPRMf7D9eFEUNs=",
      "url": "_framework/Microsoft.Extensions.Localization.xcslyy3nju.wasm"
    },
    {
      "hash": "sha256-af4JC8z9C1KAIKxrnOPCrax9UqXdeb2yCyqGEvN5zbU=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.fys0vcwxru.wasm"
    },
    {
      "hash": "sha256-JXHmg5fR3RpxHRcGNyzSfoq8wkSILgVx4J/lVHa13y8=",
      "url": "_framework/Microsoft.Extensions.Logging.dy5gfgwl7j.wasm"
    },
    {
      "hash": "sha256-D36q/cad1vAbTXK6ZoXyZfvoSeT2Z4XzkfaFrQOJ824=",
      "url": "_framework/Microsoft.Extensions.Options.n2bsjd9ih3.wasm"
    },
    {
      "hash": "sha256-rv3r6coMKuvow6Hc6OAxeNvyB7RbniAzC9Kjjvs0zPs=",
      "url": "_framework/Microsoft.Extensions.Primitives.ic9wbsf5sl.wasm"
    },
    {
      "hash": "sha256-rCqRR1uovyMtEUZWreQRHObzOIBt/Tb6+4Hr1hjrJiM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.cok88e5v83.wasm"
    },
    {
      "hash": "sha256-zC17K9ZOTxRc+ZpFc6sggd0/7BUKbpqoeSSLBHC4SG8=",
      "url": "_framework/Microsoft.JSInterop.s42k6owbl4.wasm"
    },
    {
      "hash": "sha256-Q0tB/Ko4w6BrCYaw1UkO5UaaAbAOt08q+M3MOBwC7cc=",
      "url": "_framework/MudBlazor.vd9v2a2xd3.wasm"
    },
    {
      "hash": "sha256-C/O0+a9z23UmXZHFobYtFHYd9v2l8vp5obg7nomONhY=",
      "url": "_framework/NCalc.Core.rkqedul7ql.wasm"
    },
    {
      "hash": "sha256-82PvociksN+irnvGUX+pYlC2LTXoEzu4s2YZ9blQOp4=",
      "url": "_framework/NCalc.Domain.t8lepgwlu0.wasm"
    },
    {
      "hash": "sha256-Niw5M5rY/UP8GoAWOwZrX93WGbmtyeaGzHPB+WEtUss=",
      "url": "_framework/NCalc.Parser.2y8q01gmjj.wasm"
    },
    {
      "hash": "sha256-JSWi2Xsm92gGoBI9stvX/xhy5QEjAZjNe+j0tNeLd/Y=",
      "url": "_framework/Parlot.ti453vo5z1.wasm"
    },
    {
      "hash": "sha256-EyoQJn5y4dNIjJ+UOlePi8XVt9Aj7tMaQyM0WuhiE98=",
      "url": "_framework/Sunduk.Geometry.z4a7r0k72x.wasm"
    },
    {
      "hash": "sha256-U9AWuMH/UEknmAwnd2tYsVYQksHV8iUWkcHX7PLnFOg=",
      "url": "_framework/Sunduk.re8r528mo5.wasm"
    },
    {
      "hash": "sha256-R+rab9+GAJQXQvXMgyk5Uacc2jFBWwkn3urifNpImyg=",
      "url": "_framework/System.Collections.7oukmnogav.wasm"
    },
    {
      "hash": "sha256-0F3GfK/Wjm+cMyjzx66vWR8dL+kNCajsDHPtWh01scI=",
      "url": "_framework/System.Collections.Concurrent.kjfmu7dmlb.wasm"
    },
    {
      "hash": "sha256-ixaqYS6NYNu0YQrNJ2K6hUsokLval6ROFFTxQIBk1To=",
      "url": "_framework/System.Collections.Immutable.pzfulmrdc0.wasm"
    },
    {
      "hash": "sha256-RKB+UnCzyUmjHM8z+xHA16kb56sXJzaqKu2/qxQFHc4=",
      "url": "_framework/System.ComponentModel.Annotations.gvdi16lakz.wasm"
    },
    {
      "hash": "sha256-Zu6A6V+DBW2wtWZQyp3LR9dls70xRQR8zsBiFd1TqyA=",
      "url": "_framework/System.ComponentModel.Primitives.efzlnhp6ni.wasm"
    },
    {
      "hash": "sha256-SnOTYg3IeNG8IVMVAwvSaF3cEv3k4WQ48KcL41wziy0=",
      "url": "_framework/System.ComponentModel.ytwawerg14.wasm"
    },
    {
      "hash": "sha256-toPUGvUupGaQ9kOI8gUo1r0iWBVTl+3fxGbaG4gGOjc=",
      "url": "_framework/System.Console.6hmagjfvcq.wasm"
    },
    {
      "hash": "sha256-BMAAvOFynW8RrkQvFXV9dIe7eMIXd2hI4SXgWq/UNvE=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.cmqly9mj8e.wasm"
    },
    {
      "hash": "sha256-dhE1SWtJNoOLcyszjkiHmjrjaAQsbpy8eBArFlSi0ew=",
      "url": "_framework/System.IO.Pipelines.mpr9yuumcl.wasm"
    },
    {
      "hash": "sha256-O27Y3/Ws7ZJvt9OnraXeOgu83LZ3zdhf4/Atve7T8DY=",
      "url": "_framework/System.Linq.Expressions.v7i4trbw10.wasm"
    },
    {
      "hash": "sha256-kvTRCgXmQss5YLDn+kvw0bTv7xcpnPpMfivedQIK4M8=",
      "url": "_framework/System.Linq.udura6wc57.wasm"
    },
    {
      "hash": "sha256-69M81JAOfML7lgL1+PwPD+tFJUeXFGv+V6tJn5wi4VI=",
      "url": "_framework/System.Memory.h9gjvxz2sx.wasm"
    },
    {
      "hash": "sha256-zmIWjdRHcfVtZ1JEVyOHYKwKqL1MXr6QVPFVShbUYH0=",
      "url": "_framework/System.Net.Http.q1lxqkdmis.wasm"
    },
    {
      "hash": "sha256-esoFoG86pDoLXIYQdCVCUQK6dbWYy8AL9YfctFFRvFI=",
      "url": "_framework/System.Net.Primitives.iq0vh16ox0.wasm"
    },
    {
      "hash": "sha256-Hac/eealr+SqATkpQdb+siYurtKjEfZ0vg8e0ML/bIU=",
      "url": "_framework/System.Private.CoreLib.f1zqhdaauf.wasm"
    },
    {
      "hash": "sha256-DK9iSRbVzhzUx+ZcN25kUNmQtGTih7VYVlMOf/aChk8=",
      "url": "_framework/System.Private.Uri.01hv5p8psd.wasm"
    },
    {
      "hash": "sha256-yRkhTSfb9beUzqKC1u+AjAspZ+RQM06a0kTFYSRJ5R0=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.jt5fr4psqh.wasm"
    },
    {
      "hash": "sha256-lAnWvKnfH1rM+64mpuLGO6iXkrAsr8uy/lBUXiDVLws=",
      "url": "_framework/System.Reflection.Emit.Lightweight.o1rq3aaof1.wasm"
    },
    {
      "hash": "sha256-y+d0bHTBKWIgmpILFBZWPmMlGBaeWnEOtDuaSp8gkxI=",
      "url": "_framework/System.Reflection.Primitives.j6ybmgx1f4.wasm"
    },
    {
      "hash": "sha256-6E8RhrHDiDkjNlxxTHXxfGwYC44qna5Awm+dan5WvOA=",
      "url": "_framework/System.Runtime.0u3i4efwzj.wasm"
    },
    {
      "hash": "sha256-4S76Z6V245aKZNHQHXSxPUl98xj3MH4uXwwVR4TzF9I=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.vs9238bmr6.wasm"
    },
    {
      "hash": "sha256-dcINqnHj/vx+/dXjP0ZmXz17oPEfT4xwqdum5uQciH0=",
      "url": "_framework/System.Runtime.InteropServices.tms6ssaz0a.wasm"
    },
    {
      "hash": "sha256-Ew1QnEqCmBJMtkTu7mNvPAd9VRx7YJftBwjJfmTE1Xg=",
      "url": "_framework/System.Runtime.Intrinsics.vhdn1mvvz3.wasm"
    },
    {
      "hash": "sha256-74jCNHLhVL7G39JfXrt9jdWjag4Wgm2Dxa699VbSZGk=",
      "url": "_framework/System.Runtime.Numerics.96z8r2tkwf.wasm"
    },
    {
      "hash": "sha256-dxzQIWl+zu+UCxpmldJkIYUW2BPFvRps7q6dkQVaF5Q=",
      "url": "_framework/System.Security.Cryptography.1m3x3gb6eu.wasm"
    },
    {
      "hash": "sha256-W1atJOvazHBlLzU4Gf7pzxmn1n3J2u8kIHp9vRtvaUE=",
      "url": "_framework/System.Text.Encodings.Web.z66wzn79jh.wasm"
    },
    {
      "hash": "sha256-7ix0TB06FLq3mKs4wOQTbuyH5DYM181U65R19YEKLww=",
      "url": "_framework/System.Text.Json.2kkwzk5yj3.wasm"
    },
    {
      "hash": "sha256-tjzJI/IQ733fDn47dX5jT89xqnA9Cw+6ARjWYCGeTCQ=",
      "url": "_framework/System.Text.RegularExpressions.mtqewd9lvv.wasm"
    },
    {
      "hash": "sha256-6DIquYoRLJVFSg2odA917kRDT38FhYxXcDWz2EAPnMQ=",
      "url": "_framework/System.Threading.wyshyddgsu.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-7Dpv7fScn+ctTsFUKqJNmf5ys1Qb4VPstcSbvSHJg4k=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-X9HNNO0PWod7guUohAjrSJMj6QxYLCm+SljNYaT8Nho=",
      "url": "_framework/dotnet.native.3bptkeu1pi.wasm"
    },
    {
      "hash": "sha256-YvNi2Q+yHnXi8iT7ROza0OEWWv2tCpuTI2Ggaeura3U=",
      "url": "_framework/dotnet.native.6ilbvndvcf.js"
    },
    {
      "hash": "sha256-6SBqDbLLy460Bxd7wMZoiO97hZfLTuF+HRhWT3elS7U=",
      "url": "_framework/dotnet.runtime.v2rwe8u38b.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Pyg+nmHGUFCNjz9y8lpXMmtaUPafUO2IzB4r8DXVVmE=",
      "url": "_framework/netstandard.lruw407asw.wasm"
    },
    {
      "hash": "sha256-m6ZSIqymI7dEHCPttRl3o710yIJV9ML1LsHpiD/0kJ0=",
      "url": "attribution.js"
    },
    {
      "hash": "sha256-mUZM63G8m73Mcidfrv5E+Y61y7a12O5mW4ezU3bxqW4=",
      "url": "css/all.min.css"
    },
    {
      "hash": "sha256-Mnj8BHsDXRLg+w6lb6XCC9fG11yhOTSruFrYp/Uz2gs=",
      "url": "css/fonts.css"
    },
    {
      "hash": "sha256-18jC0exAFO4mTJTyGJl0Y5NlxiXe6rAmxnMB8Pch2tI=",
      "url": "css/mudblazor-override.css"
    },
    {
      "hash": "sha256-aY7XiDu9cnVMKeRiYv0eYdKnaEDsLL/2e79u9odfS5s=",
      "url": "css/site.css"
    },
    {
      "hash": "sha256-AgSVXbNQIWLnM5/f1jA1t2gIWwz7NHzihRR09WBwIj4=",
      "url": "css/tokens.css"
    },
    {
      "hash": "sha256-UOx2qxrFAVl/AKWYb3aUiS76W0rY82I3v6FHI9YmO1A=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-jySELpF0vtoYpVbCrn1U9dxEQ0DBmjqe934jvKNmrb0=",
      "url": "fonts/FiraSans-OFL.txt"
    },
    {
      "hash": "sha256-ilx2QQMCp1tZKVpCufptaBUxH/oyhP1A8AhQ3cIjcVk=",
      "url": "fonts/firasans-400-cyrillic.woff2"
    },
    {
      "hash": "sha256-44+/e92wOZnhLxy/vQvqY4sQPxAcVaO8nMG0UJ9MAKs=",
      "url": "fonts/firasans-400-latin.woff2"
    },
    {
      "hash": "sha256-J/RGt9sfO+m4qP2kC4uDBxffJa2Wuei2slk1W4LzGGg=",
      "url": "fonts/firasans-500-cyrillic.woff2"
    },
    {
      "hash": "sha256-ig4ZsBJ8ay/VIDGVCs/zmJBvMNiiKYK3D/OEKtu299w=",
      "url": "fonts/firasans-500-latin.woff2"
    },
    {
      "hash": "sha256-Cz8xopOHfrkRZQsqb8Vn/KrjXhILDZO4fOmtsRMEKFI=",
      "url": "fonts/firasans-600-cyrillic.woff2"
    },
    {
      "hash": "sha256-h9llNKqT9fNxLMVRpty3dv0Wh1ue9wkCHsnXCyNMPQw=",
      "url": "fonts/firasans-600-latin.woff2"
    },
    {
      "hash": "sha256-sVOu9TwjW9Fj16KuEnhY3oBtgJRH5Z/a9s7DmMoebNM=",
      "url": "fonts/firasans-700-cyrillic.woff2"
    },
    {
      "hash": "sha256-OWj4p4lUp0bOZ86bWWeKs2hO+YZ2IDwLwhRmrOPwvc0=",
      "url": "fonts/firasans-700-latin.woff2"
    },
    {
      "hash": "sha256-YiE76KeLQvHinRRS2R4viz50VXKp3ZjTlB45+gCzfXY=",
      "url": "fonts/jetbrainsmono-400-cyrillic-ext.woff2"
    },
    {
      "hash": "sha256-4Xz9FfuWkJ1kCVAV+VggcGOgwHGR2jUS331WCnga698=",
      "url": "fonts/jetbrainsmono-400-cyrillic.woff2"
    },
    {
      "hash": "sha256-g8AF1J2KalBHTHOlo2rARoB26cSinae9sUmV2AVgpb4=",
      "url": "fonts/jetbrainsmono-400-latin.woff2"
    },
    {
      "hash": "sha256-YiE76KeLQvHinRRS2R4viz50VXKp3ZjTlB45+gCzfXY=",
      "url": "fonts/jetbrainsmono-500-cyrillic-ext.woff2"
    },
    {
      "hash": "sha256-4Xz9FfuWkJ1kCVAV+VggcGOgwHGR2jUS331WCnga698=",
      "url": "fonts/jetbrainsmono-500-cyrillic.woff2"
    },
    {
      "hash": "sha256-g8AF1J2KalBHTHOlo2rARoB26cSinae9sUmV2AVgpb4=",
      "url": "fonts/jetbrainsmono-500-latin.woff2"
    },
    {
      "hash": "sha256-YiE76KeLQvHinRRS2R4viz50VXKp3ZjTlB45+gCzfXY=",
      "url": "fonts/jetbrainsmono-600-cyrillic-ext.woff2"
    },
    {
      "hash": "sha256-4Xz9FfuWkJ1kCVAV+VggcGOgwHGR2jUS331WCnga698=",
      "url": "fonts/jetbrainsmono-600-cyrillic.woff2"
    },
    {
      "hash": "sha256-g8AF1J2KalBHTHOlo2rARoB26cSinae9sUmV2AVgpb4=",
      "url": "fonts/jetbrainsmono-600-latin.woff2"
    },
    {
      "hash": "sha256-zW1d/bhgB1CIaX3AwU0cvkc6/lzxQ1wB8hyISmDv2JM=",
      "url": "fonts/saira-stencil-one-v18-latin-regular.woff2"
    },
    {
      "hash": "sha256-sZHbmLthBqhCLOSXCuz0OcgenRHaC2FkqJCvELnjxDc=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-p6w3pcH39uX/+v4Hpsad8hfh3gFAAhtZbNIthXWhA34=",
      "url": "img/android_setup_1.png"
    },
    {
      "hash": "sha256-b9BPWah/1CtXrAn7SZaYrrw5aAE6DFCOsCnhOgLsMW4=",
      "url": "img/android_setup_2.png"
    },
    {
      "hash": "sha256-28dyGe+Z6gGPAxMtwIVr+4cVAnZM5uZBx4ntsvmPL30=",
      "url": "img/apple_setup_1.png"
    },
    {
      "hash": "sha256-P6Zmb2FiM7R2RBrrzVRvyQ56sLPZ+76wBtTikcEDTao=",
      "url": "img/apple_setup_2.png"
    },
    {
      "hash": "sha256-kwcBuGMQp0D+eyIcBk7Ju8cfnSfS3ZJgQ4C42tWown0=",
      "url": "img/logo-disc.png"
    },
    {
      "hash": "sha256-ABLTtu7ZAZ7g9u+XI1bAkU7v78Inet4w6GZ3PLaC5iA=",
      "url": "img/logo-mark.png"
    },
    {
      "hash": "sha256-xXtM4HceWHwdbOkP+j4y6eQrOTZmeOmdQh6910jw4eQ=",
      "url": "img/stuffimages/arc2/arc2.svg"
    },
    {
      "hash": "sha256-iaJC0SWOLGpLIOyZubvLsyUcGnpjYvLCLeimMr6jRzA=",
      "url": "img/stuffimages/arc2/arc2_bez.svg"
    },
    {
      "hash": "sha256-g+jDw9ZDTjoquSwZtaPF0GBdH1zb0IlsSJpMupy9E1U=",
      "url": "img/stuffimages/arc2/arc2_part_diam.svg"
    },
    {
      "hash": "sha256-HWP+Ve9Rx+iGaoob4jMU67BRCDk4q0+tPfLlyw9CgNo=",
      "url": "img/stuffimages/arc2/arc2_radius.svg"
    },
    {
      "hash": "sha256-qh/RsIjnEIGz0I2/2kI0Qgh1d8uT2rJCxifFaBK+8eg=",
      "url": "img/stuffimages/arc2/arc2_start_diam.svg"
    },
    {
      "hash": "sha256-SsOz8/2Sd0ofW2vqc3xIUZ6VdBuTTjP8MkMcJFfPskw=",
      "url": "img/stuffimages/arc2/arc2_tool_radius.svg"
    },
    {
      "hash": "sha256-EERcP13KljbgHH0otaNWT2xNZqagWfpmp4BU+desd54=",
      "url": "img/stuffimages/arc_chord/arc_lenght.svg"
    },
    {
      "hash": "sha256-z7R/LHp4T3As4cXmmshdBWKeWqVOvWW06ILpLnhjLD0=",
      "url": "img/stuffimages/arc_chord/arc_lenght_arc_lenght.svg"
    },
    {
      "hash": "sha256-nW3lxo2Eg3L4kkaCESHfwm9HgPZY5hi0hLnkz7HlFM4=",
      "url": "img/stuffimages/arc_chord/arc_lenght_arc_radius.svg"
    },
    {
      "hash": "sha256-6Th8qgy5nfus+bRGmvFkdx1boA74bUBrsItZOrZLswI=",
      "url": "img/stuffimages/arc_chord/arc_lenght_part_diam.svg"
    },
    {
      "hash": "sha256-CzvrQD/Oe5HypK6kdoR4hh6dHLQI49lqJ4wPw47gfV8=",
      "url": "img/stuffimages/arc_chord/arc_lenght_tool_radius.svg"
    },
    {
      "hash": "sha256-QJrsbL5MPfLsn3iS1XD8rqIVrKZEGPZT5hno3jut8NM=",
      "url": "img/stuffimages/chamfer/ext_chamfer.svg"
    },
    {
      "hash": "sha256-h0SKO/dH3qZKyauIYsXVnnSGQyK8vqVZFoKbaw+HhUc=",
      "url": "img/stuffimages/chamfer/ext_chamfer_angle.svg"
    },
    {
      "hash": "sha256-K9W3PBizbYmb3ZuU88Ot91tt/Hfe1RlWwo7qCy+hIbw=",
      "url": "img/stuffimages/chamfer/ext_chamfer_angle_n.svg"
    },
    {
      "hash": "sha256-3DpcBCyeJAiR9pq0oemfvsWpV0QBPGY5AMdPHsvghDM=",
      "url": "img/stuffimages/chamfer/ext_chamfer_diam.svg"
    },
    {
      "hash": "sha256-na9lnTw2leWX62xduuetCG8Zfv8AWU8qEDTFB7bwWeU=",
      "url": "img/stuffimages/chamfer/ext_chamfer_diam_n.svg"
    },
    {
      "hash": "sha256-n1TL6hkMwkZr00ZfOXrn96C5Ym0bXkFkW/5ddm8b4Vg=",
      "url": "img/stuffimages/chamfer/ext_chamfer_n.svg"
    },
    {
      "hash": "sha256-GKb799HQc98Bjgtwh4aogoqylUIxzwgA+PoCS7EVOhE=",
      "url": "img/stuffimages/chamfer/ext_chamfer_size.svg"
    },
    {
      "hash": "sha256-YWbhXQfjkpYtQ4vsnihcti2LehPqECxT5KvEMEMAyZE=",
      "url": "img/stuffimages/chamfer/ext_chamfer_size_n.svg"
    },
    {
      "hash": "sha256-12KDQsTsvmAIpim90Evut6fmK3OQukdZQ4SS4hx5zis=",
      "url": "img/stuffimages/chamfer/ext_part_diam.svg"
    },
    {
      "hash": "sha256-8FE0lu5qiAwDbDVoz/PH9Vop0Szh+hVNIroZpHS4NW4=",
      "url": "img/stuffimages/chamfer/ext_part_diam_n.svg"
    },
    {
      "hash": "sha256-IBCd2TY234iM9OcC8qlMkW2l70vBsd4lPpPrcOoijPo=",
      "url": "img/stuffimages/chamfer/ext_tool_radius.svg"
    },
    {
      "hash": "sha256-KqifUqlpjX/DixE+a05UTS+9zZW+HeAc0VKKn0/zAgA=",
      "url": "img/stuffimages/chamfer/ext_tool_radius_n.svg"
    },
    {
      "hash": "sha256-Ib8S3z3QodOyFqxMTXN4DIVs4t+p/Jg7DnHRxRzTjl0=",
      "url": "img/stuffimages/chamfer/int_chamfer.svg"
    },
    {
      "hash": "sha256-uEPFvbCZ7zIWfQhjVPBU8ddyhKEIs5bqKRB7zfazBPY=",
      "url": "img/stuffimages/chamfer/int_chamfer_angle.svg"
    },
    {
      "hash": "sha256-bw207Hsu7mA1dKC07YD42stN0AmV3F2LvZK1MNGg4Ng=",
      "url": "img/stuffimages/chamfer/int_chamfer_angle_n.svg"
    },
    {
      "hash": "sha256-41rbogggDq2m6fli9s0YUEGGRcRW4rcnoRjBzFBLzgI=",
      "url": "img/stuffimages/chamfer/int_chamfer_diam.svg"
    },
    {
      "hash": "sha256-nt1n6QysWKFAbvrWcFvUCIe3sIYnAadd7VzLk+gWxJY=",
      "url": "img/stuffimages/chamfer/int_chamfer_diam_n.svg"
    },
    {
      "hash": "sha256-2dWIslIWSe4MxFXt9yyqhBF0pEBbZGxvoC6wxe3Z+0Q=",
      "url": "img/stuffimages/chamfer/int_chamfer_n.svg"
    },
    {
      "hash": "sha256-uLNGngHA8TlLlQH7eCu24F7wX2xMPSNKOoFkulwvpjk=",
      "url": "img/stuffimages/chamfer/int_chamfer_size.svg"
    },
    {
      "hash": "sha256-5QCk/F9q0haHPQ1G2T79kOBBOvWJQkN2iNwI5stXnQk=",
      "url": "img/stuffimages/chamfer/int_chamfer_size_n.svg"
    },
    {
      "hash": "sha256-jm1e2C/Z2C2O1EwblN3fDS7eBJg9epmL1mVnBptOW9g=",
      "url": "img/stuffimages/chamfer/int_part_diam.svg"
    },
    {
      "hash": "sha256-gBenrlCIkGLv0qn0ak/X09RvLte62YgfMkWY3SnUTYM=",
      "url": "img/stuffimages/chamfer/int_part_diam_n.svg"
    },
    {
      "hash": "sha256-lV09dye2oq+8hD1iSz9x4peoCCysNPH6bYuzGdTQBP8=",
      "url": "img/stuffimages/chamfer/int_tool_radius.svg"
    },
    {
      "hash": "sha256-bm3ARhG4KP6ZDFc+z0ZyvdUCoXyoyL0YTcVQBzyhwXM=",
      "url": "img/stuffimages/chamfer/int_tool_radius_n.svg"
    },
    {
      "hash": "sha256-lHwdUpc+AEl7mvJBXOXXn1IUmauX9nxHhqODO8/dsEo=",
      "url": "img/stuffimages/drill/drill_angle.svg"
    },
    {
      "hash": "sha256-mYwkpVRhH+IrK8o/vIEaw0emUZDEwkmiJ9Z/sJs9VlY=",
      "url": "img/stuffimages/drill/drill_angle_n.svg"
    },
    {
      "hash": "sha256-E0GItBacihSRd4YIWMwGO/5wEuZwYOg+qFicEzCjyus=",
      "url": "img/stuffimages/drill/drill_diam.svg"
    },
    {
      "hash": "sha256-ELcFRSXsqKnL/+Q1Obc+QKRmMfgLbQ5NOdRqSBwytYM=",
      "url": "img/stuffimages/drill/drill_diam_n.svg"
    },
    {
      "hash": "sha256-UGm2W7JaKHu0eIK02SPlGDFoSFE6cUu07KDJhV9zRLE=",
      "url": "img/stuffimages/drill/drill_n.svg"
    },
    {
      "hash": "sha256-z0+hgBaBP6ac8N0JsO4XMvUKUPWNocIQv3uB51m+UWU=",
      "url": "img/stuffimages/hole_capacity/hole_capacity.svg"
    },
    {
      "hash": "sha256-koIUhJAAgNiXdF2gOG9crza09KSquX3FsN7rOBHxvYk=",
      "url": "img/stuffimages/hole_capacity/hole_capacity_hole_diam.svg"
    },
    {
      "hash": "sha256-tiF614iM8IsFHKYyMHY4G0c96+W20GnImf6JyuHsw6g=",
      "url": "img/stuffimages/hole_capacity/hole_capacity_min_diam.svg"
    },
    {
      "hash": "sha256-3JCfXAWulBVmKMCw5wkMXSG3UspmbsHvpYp5GAntpsQ=",
      "url": "img/stuffimages/hole_capacity/hole_capacity_tool_size.svg"
    },
    {
      "hash": "sha256-KV6/vhdCtYp3TyiG7bflr+wbKZ4GuXzD3JNMCdObS+A=",
      "url": "img/stuffimages/nipple/nipple.svg"
    },
    {
      "hash": "sha256-pEwy1L6SNPtZe1Xq5C4TpSLcfWsduatlWGuK2KpA/uA=",
      "url": "img/stuffimages/nipple/nipple_arc_center.svg"
    },
    {
      "hash": "sha256-auNMtyoItfk/ucQ+6OKzZWkMQzCSzft1QWX8x/omsUU=",
      "url": "img/stuffimages/nipple/nipple_diam.svg"
    },
    {
      "hash": "sha256-tNMrKpvYf5F258FTPegdJlHbLukRn+Df8AH4DI7nK/U=",
      "url": "img/stuffimages/nipple/nipple_radius.svg"
    },
    {
      "hash": "sha256-XxnP7SkF+hy+eXqz0uFmIF4f+4GQZeX/oBabmhvKyCc=",
      "url": "img/stuffimages/nipple/nipple_tool_radius.svg"
    },
    {
      "hash": "sha256-U2M6TDdkzQgC3nJhlzJr+dly3+MoSrhaUtXJjhsdORI=",
      "url": "img/stuffimages/radius/ext_part_diam.svg"
    },
    {
      "hash": "sha256-sQq7UAnoDRk2JKEV/OwuTfpuWtXqSv6BBos6u3lLpR4=",
      "url": "img/stuffimages/radius/ext_part_diam_n.svg"
    },
    {
      "hash": "sha256-fqeJJWwjOle+m7GP27HxYOmvVChnkOaLh2I5wQ6EQf0=",
      "url": "img/stuffimages/radius/ext_part_radius.svg"
    },
    {
      "hash": "sha256-xoDIHTzCOrDDoAqqrqHFR6c3/wIg9hW/AhNDl/pY5ak=",
      "url": "img/stuffimages/radius/ext_part_radius_n.svg"
    },
    {
      "hash": "sha256-Dp+fymmyK2SXEW9UNXcYbJepUyNB5KwbbMgWjvaAyFg=",
      "url": "img/stuffimages/radius/ext_radius.svg"
    },
    {
      "hash": "sha256-cNb0OycP+yu3Z8bT8D0cus7iDfNLSyqoUCN81GLxKII=",
      "url": "img/stuffimages/radius/ext_radius_n.svg"
    },
    {
      "hash": "sha256-c3571Hu357PWxX9eex0oPKhrRvoKxS37NJu/oR6qjjs=",
      "url": "img/stuffimages/radius/ext_tool_radius.svg"
    },
    {
      "hash": "sha256-RuZsNi6Yypr+u8mdHcZKWUKNxF7W2u75VJPW4ybjL88=",
      "url": "img/stuffimages/radius/ext_tool_radius_n.svg"
    },
    {
      "hash": "sha256-scES+jDv0MHiKjaIOA19VJLWoeyzr9Y0bpUzn9dK2qI=",
      "url": "img/stuffimages/radius/int_part_diam.svg"
    },
    {
      "hash": "sha256-uZf7eS25Z2IeOihcDqaSxErTgxmncok4tPKgloWLk04=",
      "url": "img/stuffimages/radius/int_part_diam_n.svg"
    },
    {
      "hash": "sha256-tocGbxq1KN/QSCdKOf0CZ1mTTzlqdTBmiR6ZT8wZDzo=",
      "url": "img/stuffimages/radius/int_part_radius.svg"
    },
    {
      "hash": "sha256-M2hLoPfeUgkG9hvUFwaIw2NQz4vj2ZkFRmHeB/FxYjw=",
      "url": "img/stuffimages/radius/int_part_radius_n.svg"
    },
    {
      "hash": "sha256-8uxoRf3FDtQB+VjiKV3YxP6JMDF3T1tymzJaWnFossI=",
      "url": "img/stuffimages/radius/int_radius.svg"
    },
    {
      "hash": "sha256-Bsv+g1En80CnbP92q0bTirAETaEiWKf72Gg2kv8bn9s=",
      "url": "img/stuffimages/radius/int_radius_n.svg"
    },
    {
      "hash": "sha256-N+zzldtx2pxqLzP02s2/vBbRmLfRS92SgtcXxAUN+wA=",
      "url": "img/stuffimages/radius/int_tool_radius.svg"
    },
    {
      "hash": "sha256-qaeizXh0LmMY301QbXYF1NTpZ5uvYhJ8da6wUAo1gSU=",
      "url": "img/stuffimages/radius/int_tool_radius_n.svg"
    },
    {
      "hash": "sha256-9XgKQMLXExjquJHjyWh/wI3VUFnRmlYqvK9LOpoo2yg=",
      "url": "img/stuffimages/tool_vectors/vector_0-9.svg"
    },
    {
      "hash": "sha256-ypnsyCE4QoogTlCqXmSyJbIgNKQuZPeHim2JiGQ9QTE=",
      "url": "img/stuffimages/tool_vectors/vector_1.svg"
    },
    {
      "hash": "sha256-ybtMJFRJ1K/Uj6WaHBH253HThWHYY9yxrBgTiXQgCvo=",
      "url": "img/stuffimages/tool_vectors/vector_2.svg"
    },
    {
      "hash": "sha256-8RrOf3zAgCXsa8K/QoJYtCuyWQZ5tYHPOULtX1DZb8s=",
      "url": "img/stuffimages/tool_vectors/vector_3.svg"
    },
    {
      "hash": "sha256-Via7UyO5TjB6RU11w9Kn+oH/bvPcis5zWyzmCEH2miE=",
      "url": "img/stuffimages/tool_vectors/vector_4.svg"
    },
    {
      "hash": "sha256-UuQL8zQF/wPNq/g1NDW1EJmZsw88OMniZMoLnM6CxTE=",
      "url": "img/stuffimages/tool_vectors/vector_5.svg"
    },
    {
      "hash": "sha256-cZfhjN2UIRkiQgCVa3MG7+CmHZQ/6W6nd1n3LZQ2qs8=",
      "url": "img/stuffimages/tool_vectors/vector_6.svg"
    },
    {
      "hash": "sha256-q3qHNsMdOOa1gbO0DLqVwwzeGCPEKPBY9TPTwNI2FtQ=",
      "url": "img/stuffimages/tool_vectors/vector_7.svg"
    },
    {
      "hash": "sha256-1xsznkcuZhbq+BbM0ijnMsn7Y+zZY8mFV40wDiffOjM=",
      "url": "img/stuffimages/tool_vectors/vector_8.svg"
    },
    {
      "hash": "sha256-wm44mrNvebs7e7XEAbRufv4+svD6OlapZWj53Vhcl+s=",
      "url": "index.html"
    },
    {
      "hash": "sha256-dkJhmuCObkkfiYASDDUtUhqonoYHn1OBcbIu8bGYwWo=",
      "url": "js/analytics.js"
    },
    {
      "hash": "sha256-2Z4Ny7ZYefS2lch9S4SxY5Bl7pYVu31h1IotlSiXhew=",
      "url": "js/appearance.js"
    },
    {
      "hash": "sha256-Gu0p5q7PTVly31rSsAopBNkP6I1uryejoggQLB1OZFg=",
      "url": "js/utils.js"
    },
    {
      "hash": "sha256-nQLJN2IO1e4HG92gE4I2BhdCK8REILivt/GwmE4mzks=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-TddPu5njvJKxeh53Lz9JAiZ5yRbcJZ9wQ/uSz6tBKMk=",
      "url": "qr.png"
    },
    {
      "hash": "sha256-MQqC2Adspel1/fkXjfn00LS1HVMFhjZUK/0xcZ+Gvtw=",
      "url": "qr.svg"
    },
    {
      "hash": "sha256-8ggzRxdcj8+pGyzAnzQuny8FjqwVDwDpwhgz8eTer9Q=",
      "url": "v.svg"
    },
    {
      "hash": "sha256-5CmUZOewEpaO7WOsLbHJUJ9WvKQJ759x8pJqjDyAsqk=",
      "url": "webfonts/fa-brands-400.eot"
    },
    {
      "hash": "sha256-o7mBd4AhTK8B6K7CC83CMFof80oV+ugezQkj35zVzQo=",
      "url": "webfonts/fa-brands-400.svg"
    },
    {
      "hash": "sha256-zaWdbv/6aFgw/ZW1X2SunLUSec00skELafhMfsMBV9k=",
      "url": "webfonts/fa-brands-400.ttf"
    },
    {
      "hash": "sha256-+SF/ZodLDAHNjBC2opXbxPYJrLb1rcQcN9pGZBtX6wI=",
      "url": "webfonts/fa-brands-400.woff"
    },
    {
      "hash": "sha256-jqh5F1SRWomKMQDmPjKXim0XY75t+Oc6OdOpDWkc3u8=",
      "url": "webfonts/fa-brands-400.woff2"
    },
    {
      "hash": "sha256-edCIBkvrOCYFT7iBZUFiNYl6hWypUvyhSYscWbFqqkg=",
      "url": "webfonts/fa-regular-400.eot"
    },
    {
      "hash": "sha256-vgoISWLYBmiE9/6b0n7BblH1qTtypQLJLFok3IfrLrw=",
      "url": "webfonts/fa-regular-400.svg"
    },
    {
      "hash": "sha256-6HEbu4ca/Y6d6mDhbTDwDH5IN7vJgHBlAXR1uEn6IxM=",
      "url": "webfonts/fa-regular-400.ttf"
    },
    {
      "hash": "sha256-y56eaTGSQTzeKx8hwdwdRLb+eyfMK0WOizWdGPn/j04=",
      "url": "webfonts/fa-regular-400.woff"
    },
    {
      "hash": "sha256-5CqIRERIrD1gVJzHwf8sipyschA0wHPYChSkTnlzDMo=",
      "url": "webfonts/fa-regular-400.woff2"
    },
    {
      "hash": "sha256-NzwE/SQY9cd+6knVFHMQWPGQepT/O05dfD5XZ+i1PYs=",
      "url": "webfonts/fa-solid-900.eot"
    },
    {
      "hash": "sha256-lnTrG9VQRxeQODcJOmdmjqiPLtAG2RNn0NS3qh+SEfw=",
      "url": "webfonts/fa-solid-900.svg"
    },
    {
      "hash": "sha256-r2OXUD/O+9YTl2whrVweNymMGLvgfQltsDzNOvbgW6g=",
      "url": "webfonts/fa-solid-900.ttf"
    },
    {
      "hash": "sha256-P200iM9lN09vZ2wxU0CwrCvoMr1VJAyAlEjjbvm5YyY=",
      "url": "webfonts/fa-solid-900.woff"
    },
    {
      "hash": "sha256-mDS4KtJuKjdYPSJnahLdLrD+fIA1aiEU0NsaqLOJlTc=",
      "url": "webfonts/fa-solid-900.woff2"
    }
  ]
};
